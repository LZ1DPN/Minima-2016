
void debug(char const *fmt, ... );
